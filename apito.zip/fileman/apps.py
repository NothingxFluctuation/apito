from django.apps import AppConfig


class FilemanConfig(AppConfig):
    name = 'fileman'
